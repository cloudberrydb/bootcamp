COPY tpcds_reports.ddl FROM :LOGFILE WITH DELIMITER '|';
