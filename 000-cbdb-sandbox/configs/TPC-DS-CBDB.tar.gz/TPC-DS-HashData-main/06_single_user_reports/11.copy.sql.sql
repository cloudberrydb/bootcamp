COPY tpcds_reports.sql FROM :LOGFILE WITH DELIMITER '|';
