DROP SCHEMA IF EXISTS tpcds_testing CASCADE;
CREATE SCHEMA tpcds_testing;
