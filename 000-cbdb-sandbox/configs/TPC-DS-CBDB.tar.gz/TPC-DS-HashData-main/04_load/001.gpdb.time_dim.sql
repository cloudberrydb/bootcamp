INSERT INTO tpcds.time_dim SELECT * FROM ext_tpcds.time_dim;
