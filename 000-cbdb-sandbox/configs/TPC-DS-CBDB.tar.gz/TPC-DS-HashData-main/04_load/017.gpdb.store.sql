INSERT INTO tpcds.store SELECT * FROM ext_tpcds.store;
