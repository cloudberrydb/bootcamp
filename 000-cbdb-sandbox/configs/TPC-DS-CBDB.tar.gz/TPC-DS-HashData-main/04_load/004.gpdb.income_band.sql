INSERT INTO tpcds.income_band SELECT * FROM ext_tpcds.income_band;
