---
name: "\U0001F680 Feature Request"
about: As a user, I want to request a new feature.
labels: "type: feature"
---

## Feature Request

**Is your feature request related to a problem? Please describe:**
<!-- A clear and concise description of what the problem is. -->

**Describe the feature you'd like to request:**
<!-- A clear and concise description of what you want to happen. -->
