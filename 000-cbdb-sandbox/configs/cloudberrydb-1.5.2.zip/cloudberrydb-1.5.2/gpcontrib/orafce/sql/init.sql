\set ECHO none
set client_min_messages TO error;
CREATE EXTENSION IF NOT EXISTS orafce;
set client_min_messages TO default;