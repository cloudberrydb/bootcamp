cat behave.out | ./parse_behave.py
