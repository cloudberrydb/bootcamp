typedef struct
{
	int		typenode;
	char   *str;
	int		keycode;
	int		lloc;
	char   *sep;
	char   *modificator;
	char   *classname;
} orafce_lexnode;
