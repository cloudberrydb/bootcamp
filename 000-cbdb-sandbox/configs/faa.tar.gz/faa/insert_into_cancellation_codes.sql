insert into faa.d_cancellation_codes values ('A', 'Carrier'), ('B', 'Weather'), ('C', 'NAS'), ('D', 'Security'), ('', 'none');

