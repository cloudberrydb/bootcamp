COPY tpch_reports.gen_data FROM :LOGFILE WITH DELIMITER '|';
