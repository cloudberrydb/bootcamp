COPY tpch_reports.sql FROM :LOGFILE WITH DELIMITER '|';
