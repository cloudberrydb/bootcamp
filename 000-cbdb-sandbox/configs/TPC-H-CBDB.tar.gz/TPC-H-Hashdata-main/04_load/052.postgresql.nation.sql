COPY :schema_name.nation FROM :filename WITH DELIMITER '|' NULL '';
