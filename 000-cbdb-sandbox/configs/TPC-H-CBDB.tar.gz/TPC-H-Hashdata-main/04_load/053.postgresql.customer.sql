COPY :schema_name.customer FROM :filename WITH DELIMITER '|' NULL '';
