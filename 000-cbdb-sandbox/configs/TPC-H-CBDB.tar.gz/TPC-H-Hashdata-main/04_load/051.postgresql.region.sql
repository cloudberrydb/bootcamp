COPY :schema_name.region FROM :filename WITH DELIMITER '|' NULL '';
