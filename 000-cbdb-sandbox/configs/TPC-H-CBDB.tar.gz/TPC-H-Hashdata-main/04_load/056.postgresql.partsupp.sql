COPY :schema_name.partsupp FROM :filename WITH DELIMITER '|' NULL '';
