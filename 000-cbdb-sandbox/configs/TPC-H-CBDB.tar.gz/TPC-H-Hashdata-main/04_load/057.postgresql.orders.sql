COPY :schema_name.orders FROM :filename WITH DELIMITER '|' NULL '';
