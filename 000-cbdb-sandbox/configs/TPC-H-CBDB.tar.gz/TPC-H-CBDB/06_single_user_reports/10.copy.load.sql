COPY tpch_reports.load FROM :LOGFILE WITH DELIMITER '|';
