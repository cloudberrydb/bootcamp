COPY tpch_reports.compile_tpch FROM :LOGFILE WITH DELIMITER '|';
