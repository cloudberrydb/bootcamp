COPY tpch_reports.init FROM :LOGFILE WITH DELIMITER '|';
