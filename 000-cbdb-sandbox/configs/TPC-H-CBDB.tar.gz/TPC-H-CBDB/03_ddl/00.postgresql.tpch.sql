DROP SCHEMA IF EXISTS :schema_name CASCADE;
DROP SCHEMA IF EXISTS :ext_schema_name CASCADE;
CREATE SCHEMA :schema_name;
CREATE SCHEMA :ext_schema_name;
