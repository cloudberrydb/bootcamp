COPY :schema_name.lineitem FROM :filename WITH DELIMITER '|' NULL '';
