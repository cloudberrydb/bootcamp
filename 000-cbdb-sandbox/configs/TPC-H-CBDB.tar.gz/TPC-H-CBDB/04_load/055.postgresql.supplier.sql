COPY :schema_name.supplier FROM :filename WITH DELIMITER '|' NULL '';
