COPY :schema_name.part FROM :filename WITH DELIMITER '|' NULL '';
